create
    definer = root@localhost procedure pro_testInOut(INOUT n int)
begin
	select n;	-- 查看变量的值
	set n=500;	-- 修改变量的值
end;

