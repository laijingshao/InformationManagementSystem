create
    definer = root@localhost procedure pro_testWhile(IN num int, OUT result int)
begin
	-- 定义局部变量
	declare i int default 1;
	declare vsum int default 0;
	-- 循环 关键字while do end while
	while i<=num do
		set vsum=vsum+i;
		set i=i+1;
	end while;
	set result=vsum;
end;

