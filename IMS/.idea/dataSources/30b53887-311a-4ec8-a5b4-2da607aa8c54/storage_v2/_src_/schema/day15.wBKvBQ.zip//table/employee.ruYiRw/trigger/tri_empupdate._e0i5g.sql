create definer = root@localhost trigger tri_empUpdate
    after UPDATE
    on employee
    for each row
    insert into test_log(content) values('员工表修改了一条记录');

