create definer = root@localhost trigger tri_empDelete
    after DELETE
    on employee
    for each row
    insert into test_log(content) values('员工表删除了一条记录');

