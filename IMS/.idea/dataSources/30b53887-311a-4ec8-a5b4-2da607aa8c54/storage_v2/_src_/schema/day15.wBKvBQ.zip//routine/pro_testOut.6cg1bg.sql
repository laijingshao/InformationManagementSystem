create
    definer = root@localhost procedure pro_testOut(OUT str varchar(20))
begin
	-- 给参数赋值
	set str='hello';
end;

