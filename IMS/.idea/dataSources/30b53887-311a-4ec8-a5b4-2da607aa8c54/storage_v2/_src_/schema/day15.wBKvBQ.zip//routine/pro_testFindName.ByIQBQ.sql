create
    definer = root@localhost procedure pro_testFindName(IN eid int, OUT eName varchar(20))
begin
	select name into eName from employee where id=eid;
end;

