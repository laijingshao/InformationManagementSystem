create
    definer = root@localhost procedure pro_testIf(IN i int, OUT str varchar(20))
begin
	if i=1 then
		set str='星期一';
	elseif i=2 then
		set str='星期二';
	elseif i=3 then
		set str='星期三';
	elseif i=4 then
		set str='星期四';
	elseif i=5 then
		set str='星期五';
	elseif i=6 then
		set str='星期六';
	elseif i=7 then
		set str='星期日';
	else
		set str='输入有误';
	end if;
end;

