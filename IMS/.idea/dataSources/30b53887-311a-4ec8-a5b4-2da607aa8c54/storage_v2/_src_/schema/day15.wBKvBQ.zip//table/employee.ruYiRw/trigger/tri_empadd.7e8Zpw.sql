create definer = root@localhost trigger tri_empAdd
    after INSERT
    on employee
    for each row
    insert into test_log(content) values('员工表插入了一条记录');

