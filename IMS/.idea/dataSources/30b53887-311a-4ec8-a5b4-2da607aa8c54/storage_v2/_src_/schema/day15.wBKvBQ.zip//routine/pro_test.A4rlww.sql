create
    definer = root@localhost procedure pro_test()
begin
	-- 存储过程中可以书写多个SQL语句
	select * from employee;
end;

